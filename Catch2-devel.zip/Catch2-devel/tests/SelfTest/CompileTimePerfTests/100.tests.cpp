// Include set of usage tests multiple times - for compile-time performance testing
// (do not run)

#include "10.tests.cpp"
#include "10.tests.cpp"
#include "10.tests.cpp"
#include "10.tests.cpp"
#include "10.tests.cpp"
#include "10.tests.cpp"
#include "10.tests.cpp"
#include "10.tests.cpp"
#include "10.tests.cpp"
#include "10.tests.cpp"
